#include "header.h"


// SEE HEADER FOR AN EXPLANATION OF THIS PROGRAM
#include "hw1_header.h"

// Initialize all of the member values of a newly created message
Message::Message(void){
    // Set all pointers to null
    // Note: When deleting null pointers, don't
}

Message::~Message(void){

}

int Message::clone(Message & ref_msg){
    return 0;
}